import dotenv from 'dotenv';
dotenv.config();

console.log(process.env.PAYPAL_API);
console.log(process.env.CLIENT_ID);
console.log(process.env.CLIENT_SECRET);